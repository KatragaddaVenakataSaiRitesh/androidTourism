package com.example.androidtourismapp;

public class Destination {
    private String destinationName;
    private double destinationPrice;
    private String destinationText;
    private int destinationImage;

    public Destination(String destinationName, double destinationPrice,String destinationText, int destinationImage) {
        this.destinationName = destinationName;
        this.destinationPrice = destinationPrice;
        this.destinationText = destinationText;
        this.destinationImage = destinationImage;
    }

    public String getDestinationName() {
        return destinationName;
    }

    public double getDestinationPrice() {

        return destinationPrice;
    }
    public String getDestinationText(){
        return destinationText;
    }


    public int getDestinationImage()
    {
        return destinationImage;
    }
}


