package com.example.androidtourismapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class DestinationDetailsActivity extends AppCompatActivity implements View.OnClickListener {
    EditText et,et2;
    TextView tv1;
    ImageView iv;
    Button bn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_destination_details);
        tv1=findViewById(R.id.textView7);
        tv1.setText(MainActivity.name);
        et=findViewById(R.id.etDiscription);
        et.setText(MainActivity.text);
        et2=findViewById(R.id.editText2);
        et2.setText(String.format("%.2f",MainActivity.price));
        iv=findViewById(R.id.imageView3);
        iv.setImageResource(MainActivity.img);
        bn = findViewById(R.id.bookbtn);
        bn.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v == bn)
        {
            Intent intent = new Intent(this, Booking.class);
            startActivity(intent);
        }
    }
}
