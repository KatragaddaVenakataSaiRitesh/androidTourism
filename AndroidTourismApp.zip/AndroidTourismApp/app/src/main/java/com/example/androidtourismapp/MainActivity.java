package com.example.androidtourismapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Currency;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemClickListener{
    public static int cNum;
    ListView destinationList;
    private static final String TAG = "MainActivity";
    ArrayList<Destination> destinations = new ArrayList<Destination>();
    public static String name;
    public static double price;
    public static String text;
    public static int img;
    private EditText mDisplayDate;
    private DatePickerDialog.OnDateSetListener onDateSetListener;


    public void fillDestinations(){
        destinations.add(new Destination("United States",2300,"The U.S. is a country of 50 states covering a vast swath of North America, with Alaska in the northwest and Hawaii extending the nation’s presence into the Pacific Ocean. Major Atlantic Coast cities are New York, a global finance and culture center, and capital Washington, DC.",R.drawable.usa));
        destinations.add(new Destination("Canada",8500,"Canada is a country in the northern part of North America. Its ten provinces and three territories extend from the Atlantic to the Pacific and northward into the Arctic Ocean, covering 9.98 million square kilometres, making it the world's second-largest country by total area.",R.drawable.canada));
        destinations.add(new Destination("Australia",27000,"Australia, officially the Commonwealth of Australia, is a sovereign country comprising the mainland of the Australian continent, the island of Tasmania, and numerous smaller islands. It is the largest country in Oceania and the world's sixth-largest country by total area.",R.drawable.australia));
        destinations.add(new Destination("United Kingdom",28000,"The United Kingdom, made up of England, Scotland, Wales and Northern Ireland, is an island nation in northwestern Europe. England – birthplace of Shakespeare and The Beatles – is home to the capital, London, a globally influential centre of finance and culture. England is also site of Neolithic Stonehenge, Bath’s Roman spa and centuries-old universities at Oxford and Cambridge.",R.drawable.uk));
        destinations.add(new Destination("japan",24900,"Japan is an island country located in East Asia. It is bordered by the Sea of Japan to the west and the Pacific Ocean to the east, and spans from the Sea of Okhotsk in the north to the East China Sea and Philippine Sea in the south.",R.drawable.japan));
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fillDestinations();
        destinationList=findViewById(R.id.lvDestination);
        destinationList.setAdapter(new DestinationAdapter(this, destinations));
        destinationList.setOnItemClickListener(this);
        mDisplayDate = (EditText) findViewById(R.id.etDate);
        mDisplayDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Calendar cal = Calendar.getInstance();
                int year = cal.get(Calendar.YEAR);
                int month = cal.get(Calendar.MONTH);
                int day = cal.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog dialog = new DatePickerDialog(
                        MainActivity.this,
                        android.R.style.Theme_Holo_Light_Dialog_MinWidth,
                        onDateSetListener,
                        year,month,day);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.show();
            }
        });
        onDateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                month = month + 1;
                Log.d(TAG, "onDateSet: mm/dd/yyy: " + month + "/" + day + "/" + year);
                String date = month + "/" + day + "/" + year ;
                mDisplayDate.setText(date);
            }
        };
    }
    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        name = destinations.get(i).getDestinationName();
        price = destinations.get(i).getDestinationPrice();
        text = destinations.get(i).getDestinationText();
        img = destinations.get(i).getDestinationImage();
        Intent intent = new Intent(this,DestinationDetailsActivity.class);
        startActivity(intent);

    }
}
