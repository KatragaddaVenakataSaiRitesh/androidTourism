package com.example.androidtourismapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.EditText;

public class Recipt extends AppCompatActivity {
    //EditText etn,etd,eta,etc;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipt);

       /* etn=findViewById(R.id.dName);
        etn.setText((CharSequence) Booking.cName);

        etd=findViewById(R.id.dDestination);
        etd.setText(MainActivity.cNum);

        eta=findViewById(R.id.dAmount);
        eta.setText((int) MainActivity.price);

        etc=findViewById(R.id.dCard);
        etc.setText((CharSequence) Booking.cNum);*/
    }
}
